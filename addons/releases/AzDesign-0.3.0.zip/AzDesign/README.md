# Az Design 0.3.0

A Fusion-inspired modeling workspace for **FreeCAD-Az**. Install it in standard
**FreeCAD 1.0 or newer** without compiling the fork. All code is in this repository
and can be changed as our shop workflow develops. This is an independent project;
Autodesk code and artwork are not included.

## Install or update

1. Download **[AzDesign-0.3.0.zip](../releases/AzDesign-0.3.0.zip)** and extract it.
2. In FreeCAD, choose **Macro → Macros…**. Set the macro location to the extracted
   folder, select **Install_AzDesign**, and choose **Execute**.
3. Confirm the local installation, restart FreeCAD, and choose **Az Design** from
   the workbench selector.

The installer needs no administrator rights. An existing installation is backed
up in `AzDesign-backups` beside FreeCAD's `Mod` directory before replacement.
For manual installation, copy the **AzDesign** folder into the `Mod` folder under
`App.getUserAppDataDir()` and restart FreeCAD.

## Workspace in 0.3.0

The work area now has a light canvas, original SVG tool icons, document tabs above
the tools, a Design selector on the left, a grouped Browser, compact timeline and
bottom-center navigation controls. Activating Az with no visible design opens a
normal empty Design. The native menu and auxiliary panels are available from
**File → Advanced**. **File → Native CAD / Properties** returns to Part Design and
restores the previous layout, menus, canvas colors and navigation.

- **Browser:** Bodies, Sketches, Origin, Named Views and construction geometry are
  grouped by purpose. Search filters this design. Eye icons change native
  visibility; a selected face highlights its body. Double-click a sketch to edit,
  or a body to activate it. Right-click for Properties, Isolate and Restore
  visibility. The small sliders button opens native properties.
- **Timeline:** Compact icons select features; double-click edits them and
  right-click offers rollback/suppression. Previous/Next step through the selected
  body's actual solid history; the first control goes to its first solid. A marker
  identifies the rolled-back Body Tip. The right-hand settings menu can show
  feature labels. Multiple bodies require selecting the intended body.
- **Navigation:** Home, Orbit, Pan, Fit and Zoom use the native camera. Orbit/Pan
  buttons enable left-button dragging; Esc returns to selection. Middle button
  pans and Shift + middle button orbits as before. Display settings include native
  shaded/edge/wireframe styles, orthographic/perspective cameras and an optional
  10 mm construction grid. Grid geometry is transient and excluded from Home/Fit.
- **Canvas right-click:** While idle in Solid, eight radial tools offer Sketch,
  Extrude, Press/Pull, Fillet, Hole, Move, Undo and Redo. Click a tool or press Esc.
  Active tasks and sketch drawing retain native right-click/cancel behavior.
- **Document tabs:** Switch native designs from the application bar. Closing uses
  FreeCAD's native unsaved-document confirmation. Finish active tasks before
  switching or closing a design.

This is a repo-owned Qt workspace over FreeCAD's native model/document engine.
The installable module delivers the same source without requiring a full fork
build. Core changes remain available when an API or native UI boundary requires
one. The layout follows familiar CAD conventions described in the
[Autodesk interface guide](https://help.autodesk.com/cloudhelp/ENU/Fusion-GetStarted/files/GS-THE-FUSION-INTERFACE.htm);
its code and SVG artwork are independently implemented. Advanced tasks still use
native FreeCAD dialogs. History reordering and full Fusion feature parity remain
future work. Linux/FreeCAD 1.0/Qt5 is tested; Windows 1.1/Qt6 acceptance is pending.

## First sketch fix included from 0.2.2

Create Sketch now opens a visible design automatically when none is open. You do
not need to choose New first. Az's hidden geometry calculator is never used as
the modeling document. New Body, Extrude and Parameters also check the visible
document context. Existing designs are reused, and selections in other documents
are ignored when creating a sketch or choosing its body.

The reported failure was `NoneType` having no `activeView` after starting without
a document. The fix has 13 document-context regressions, a fresh installed Linux
startup/sketch/extrusion check, and 27 passing GUI workflow checks. The owner's
Windows/FreeCAD 1.1 update and full workflow retest remain pending.

## Startup fix included from 0.2.1

If 0.2.0 reports `name '__file__' is not defined` in `InitGui.py`, install 0.3.0
with the same macro and restart FreeCAD. The update keeps a backup of the old
installation. Both startup entry scripts now import a normal package module;
they no longer assume FreeCAD defines `__file__` for its executed init scripts.
Startup regression tests cover an absent or unrelated loader `__file__`, separate
loader namespaces and installation paths with spaces/non-ASCII characters.
Full Windows/FreeCAD 1.1 modeling validation is still pending.

## Build a part

1. **Create Sketch** on XY, XZ, YZ or a selected planar face.
2. Draw geometry. **D** starts native Smart Dimension for the selected line,
   circle, points or angle. Finish Sketch returns to the Solid ribbon.
3. Press **E**. A single region is selected automatically. For a sketch with
   several regions, click its shaded areas in the view or tick the profile list.
   Nested loops, crossing dividers and overlapping closed profiles form separate
   selectable regions. Curves stay exact; they are not converted to polygons.
4. Type a distance (`6 mm`, `1/4 in`, `10 mm + 2 mm`, `Parameters.Thickness`) or
   drag the blue arrow in the viewport. Choose **Auto**, **Join**, **Cut**,
   **Intersect** or **New body** and inspect the live solid before choosing OK.
5. Select edges for native Fillet or Chamfer. Sketch on another face for a boss,
   pocket or hole. Native Part Design features can follow Az extrusion features.

**Auto** cuts when the extruded volume overlaps the target, joins when it touches,
and creates a new body when it is separate. Select a target Body explicitly when
working with several bodies. Negative distances reverse direction. Explicit Cut
uses FreeCAD Pocket's inward direction; Flip reverses it.

Disconnected regions in **New body** become separate Bodies. A Body contains one
connected solid. Distance supports **One side**, **Symmetric** (total distance) and
**Two sides** (independent distances and handles). **Through all** is available for
Cut. **To face** picks an existing planar end face. Those two extents use One side.
Expand **Start offset and taper** for signed offsets and draft angles.

Cancel restores the model, Body Tips, visibility and preview objects. OK commits
one undoable edit. Leaving Az Design cancels an unfinished Az modeling task.

## Q: Press / Pull

| Selection | Behavior |
| --- | --- |
| Sketch or no selection | Open the profile extrusion workflow |
| End cap of a supported one-sided Az extrusion or native Pad | Offset its driving Length, preserving tapered walls and parameter expressions |
| Other planar face with prismatic side walls | Preview an outward Join or inward Cut from that face |
| Cylinder generated by a unique editable sketch circle | Edit its driving diameter; an unconstrained circle receives a driving dimension |
| Native Cylinder or Hole's main cylindrical face | Edit its Radius or Diameter parameter |
| Solid edge | Open native Fillet |

End-face offsets are signed changes from the original length. Cylinder edits are
absolute diameters. Unsupported curved/imported surfaces and ambiguous source
circles produce an explanation instead of creating an unrelated solid. General
surface offsets and healing of arbitrary imported models remain future work.

## Parameters

Choose **Utilities → Parameters** (also under Solid → Modify → More). Add named
user parameters, edit model dimensions and choose **Update model** to inspect the
result. OK commits; Cancel restores the original model.

User parameters live in a native `Parameters` Spreadsheet. A value can be `8 mm`,
`1/4 in` or a spreadsheet formula such as `=Thickness / 2`. Model dimensions use
native expressions such as `Parameters.Thickness`. Driving sketch constraints and
common feature lengths, radii and angles appear in the same task. Existing alias
names are fixed in this editor; use the native Spreadsheet for structural edits.

## Editable history

The bottom strip follows each Body's native feature order. Click to select and
double-click to edit. Right-click a solid feature for **Roll back here**,
**Suppress / Unsuppress**, **Resume latest history**, visibility or rename.

Rollback changes the real Body Tip and shows that stage of the solid. New Az
extrusions insert at that position and rebase the next unique feature. Resume
Latest restores the saved end of that Body. Explicit sketch/face references stay
anchored to their original features; insertion does not rewrite design intent.
Branched histories and edits that break downstream features are rejected.

This is not a drag-to-reorder Fusion timeline. Topology-changing edits may require
reselecting native downstream face/edge references. Az region and planar-face
references record geometric intent and ask for reselection when ambiguous.

## Interface and navigation

- **Solid / Sketch / Utilities ribbon**, native Browser on the left and Tasks on
  the right. Context follows sketch editing without changing workbenches.
- **S** searches tools by familiar name or native command ID.
- Middle button pans, **Shift + middle button** orbits, wheel zooms. Native Fusion
  navigation is used when available; otherwise Az adapts Blender navigation.
- **Native CAD** restores the prior layout, toolbars and camera navigation.
  **Manufacture** opens the installed native CAM workbench.

| Context | Shortcuts |
| --- | --- |
| Solid | E Extrude; Q Press/Pull; F Fillet; H Hole; M Move; S Find a Tool |
| Sketch | L Line; R Rectangle; C Circle; D Smart Dimension; T Trim; P Project; X Construction; S Find a Tool |

Shortcuts do not intercept typing in task controls, text fields, the Python
console or modal dialogs. Existing FreeCAD shortcuts are not rewritten.

## Saved models and compatibility

**Version 0.2 extrusion results are parametric Az features**, evaluated with
FreeCAD's native Pad/Pocket and exact OCCT boolean algorithms. Keep Az Design
installed to edit/recompute those features. Their cached shapes remain available
in `.FCStd`; export STEP for an independent solid exchange file. The v0.1 native
Pad/Pocket models remain native and are not migrated or rewritten.

Verified on **FreeCAD 1.0.0, Linux, Qt 5 / PySide2**. Windows, macOS, PySide6 and
FreeCAD 1.1 have not been verified. Native Revolve, Loft, Sweep, Fillet, Hole,
Shell, patterns and CAM still use FreeCAD dialogs. Assembly/joint workflows,
Fusion-style CAM setup and arbitrary direct surface modeling are not redesigned.

## Develop and verify

| Module | Responsibility |
| --- | --- |
| `catalog.py`, `commands.py` | Editable ribbon, shortcuts and command adapters |
| `profiles.py`, `references.py` | Exact planar regions and saved geometric references |
| `features.py`, `operations.py` | Parametric solids, body frames, previews and transactions |
| `tasks.py`, `manipulator.py`, `presspull.py` | Profile/face picking, viewport arrows and Q workflows |
| `parameters.py`, `history.py` | Native expressions, user parameters, rollback and insertion |
| `modeling.py` | Body/sketch setup and retained v0.1 native adapters |
| `ui.py`, `session.py` | Ribbon, palette, history and scoped layout/navigation |
| `install.py` | Local installer, backup and recovery |

Run from the repository root:

```sh
python3 addons/AzDesign/tests/test_startup.py
python3 addons/AzDesign/tests/test_install.py
/usr/bin/python3 addons/AzDesign/tests/run_workflow.py
python3 tools/package_azdesign.py
```

The modeling runner uses a packaged FreeCAD runtime and its matching Python.
Set `FREECAD_LIB_DIR` for other installations. GitHub CI installs Debian's native
runtime and runs the geometry/parameter/history tests in addition to packaging.

For desktop tests, load Az Design and run in **View → Panels → Python console**:

```python
import runpy
suite = runpy.run_path('/path/to/AzDesign/tests/integration_v02.py')
suite['run']('/path/to/results.json', '/path/to/test_part.FCStd')
```

The native Smart Dimension tool may wait for Escape before the test continues.
`integration.py` also retains the original native-feature, navigation and layout
regressions. Test reports are checked into `tests/validation-v02-linux.json`.
These tests create separate test documents and leave results open for inspection.

## License and provenance

New code is **LGPL-2.1-or-later**. FreeCAD icons are resolved from the installed
application. This fork's changes were produced with OpenAI Codex assistance and
require owner review before an upstream submission.
